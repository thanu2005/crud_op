package com.example.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.project.model.Users;
import com.example.project.repository.UserRepository;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/reg")
    public String showRegistrationForm() {
        return "register";
    }

    @PostMapping("/reg")
    public String registerUser(@RequestParam("username") String username,
            @RequestParam("email") String email,
            @RequestParam("password") String password, Model model) {
        if (userRepository.findByUsername(username) != null) {
            model.addAttribute("errorMessage", "Username already exists!");
            return "register";
        }
        if (userRepository.findByEmail(email) != null) {
            model.addAttribute("errorMessage", "Email already exists!");
            return "register";
        }
        Users user = new Users();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        userRepository.save(user);
        return "registerSuccess";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam("username") String username,
            @RequestParam("password") String password, Model model, HttpSession session) {
        Users user = userRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            session.setAttribute("loggedInUser", username);
            return "main";
        }
        model.addAttribute("errorMessage", "Invalid Credentials");
        return "login";
    }

    @GetMapping("/update")
    public String showUpdatePage(HttpSession session, Model model) {
        String loggedInUser = (String) session.getAttribute("loggedInUser");
        if (loggedInUser == null)
            return "redirect:/login";
        model.addAttribute("username", loggedInUser);
        return "update";
    }

    @PostMapping("/update-details")
    public String updateUserDetails(@RequestParam("email") String email,
            @RequestParam("password") String password, HttpSession session, Model model) {
        String loggedInUser = (String) session.getAttribute("loggedInUser");
        if (loggedInUser == null)
            return "redirect:/login";

        Users user = userRepository.findByUsername(loggedInUser);
        if (user != null) {
            user.setEmail(email);
            user.setPassword(password);
            userRepository.save(user);
            model.addAttribute("successMessage", "User details updated successfully");
            return "updateSuccess";
        }
        return "update";
    }

    @GetMapping("/delete")
    public String showDeletePage() {
        return "delete"; // Show delete form when accessed via browser
    }

    @PostMapping("/delete")
    public String deleteUser(@RequestParam("username") String username,
            @RequestParam("password") String password,
            HttpSession session,
            Model model) {
        Users user = userRepository.findByUsername(username);

        if (user == null) {
            model.addAttribute("errorMessage", "User not found!");
            return "delete"; // Redirect back to delete page with an error message
        }

        if (!user.getPassword().equals(password)) {
            model.addAttribute("errorMessage", "Incorrect password!");
            return "delete"; // Redirect back to delete page with an error message
        }

        userRepository.delete(user);
        session.invalidate(); // Log the user out after deleting
        return "deleteSuccess"; // Redirect to delete success page
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
